create Table xyz
(
Id int,
student_name varchar(20)
);

alter table student
modify student_name varchar(50);

Insert into Student
values (
21,
'Satish'
);